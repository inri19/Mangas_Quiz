from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Liste(models.Model) :

	nom_liste = models.CharField(max_length=20)
	image = models.FileField(blank=True)

	def __str__(self):
		return self.nom_liste

class Questions(models.Model) :

	liste = models.ForeignKey(Liste, on_delete=models.CASCADE)
	question = models.CharField(max_length=100)
	choix1 = models.CharField(max_length=100)
	choix2 = models.CharField(max_length=100)
	choix3 = models.CharField(max_length=100)
	choix4 = models.CharField(max_length=100)
	reponse = models.CharField(max_length=100)

	def __str__(self) :
		return self.question
