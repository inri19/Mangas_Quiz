from django.shortcuts import render, redirect
from django.contrib.auth import login,logout,authenticate
from django.contrib import messages
from .forms import *
from .models import *

# Create your views here.

# USER AUTH
def register(request) :
	
	if request.user.is_authenticated :
		redirect('/')

	else :
		form = createuserform()

		if request.method == "POST" :

			form = createuserform(request.POST)

			if form.is_valid() :

				form.save()
				messages.success(request, "Utilisateur Creer !!")

	dico = { "form" : form }

	return render(request, "Quiz/register.html", dico)


def connexion(request) :
	
	if request.user.is_authenticated :
		redirect('/')

	else :

		if request.method == "POST" :

			user = request.POST.get("username")
			mpd = request.POST.get("password")

			if len(user) == 0 or len(mpd) == 0 :

				messages.info(request, "Veuillez remplir tous les champs")

			else :

				user = authenticate(request, username=user, password=mpd)

				if user :

					login(request, user)
					return redirect('/')

				else :

					messages.info(request, "Ce compte n esxite pas")

	dico = {}

	return render(request, "Quiz/login.html", dico)

def deconnexion(request) :
	
	logout(request)

	return redirect('/')

def home(request) :

	dico = {}

	return render(request, "Quiz/home.html", dico)

# QUIZ

def addListe(request) :

	listes = Liste.objects.all()

	if request.method == "POST" :

		nom = request.POST.get("nom_liste")
		img = request.FILES.get("img")

		if len(nom) == 0 or img is None :

			messages.info(request, "Remplissez tous les champs !")

		else :

			new_liste = Liste(nom_liste=nom, image=img)
			new_liste.save()

			messages.success(request, "Liste Creer")

	dico = { "listes" : listes }

	return render(request, "Quiz/nouvelle_liste.html", dico)

def addQuestion(request, liste_id) :

	liste = Liste.objects.get(id=liste_id)

	if request.method == "POST" :

		tab = []
		count = 0 

		ques = request.POST.get("question")
		c1 = request.POST.get("choix1")
		c2 = request.POST.get("choix2")
		c3 = request.POST.get("choix3")
		c4 = request.POST.get("choix4")
		rep = request.POST.get("rep")

		tab.append(ques)
		tab.append(c1)
		tab.append(c2)
		tab.append(c3)
		tab.append(c4)
		tab.append(rep)

		for i in tab :

			if len(i) == 0 :
				count += 1

		if count != 0 :

			messages.info(request, "Veuillez remplir tous les champs !")

		else :

			new_ques = Questions.objects.create(liste=liste, question=ques, choix1=c1, choix2=c2, choix3=c3, choix4=c4, reponse=rep)
			new_ques.save()

			messages.success(request, "Question Enregistrer")

	dico = {}

	return render(request, "Quiz/nouvelle_question.html", dico)

def liste(request) :

	listes = Liste.objects.all()

	dico = { "listes" : listes }

	return render(request, "Quiz/listes.html", dico)

def quizPage(request, liste_id) :

	liste = Liste.objects.get(id=liste_id)
	questions = Questions.objects.filter(liste=liste)

	if request.method == "POST" :

		score = 0
		correct = 0
		wrong = 0
		total = 0

		for q in questions : 

			total += 1
			#print(q.reponse)
			#print(request.POST.get(q.question))
			if q.reponse == request.POST.get(q.question) :		

				score += 10
				correct += 1

			else :

				wrong += 1

		percent = score / (total*10) * 100

		dico = {
					"score" : score ,
					"correct" : correct ,
					"wrong" : wrong ,
					"total" : total ,
					"percent" : round(percent, 1) ,
					"time" : request.POST.get('timer') ,
			   }

		return render(request, "Quiz/resultat.html", dico)

	else :

		dico = { "questions" : questions }

	return render(request, "Quiz/quiz_page.html", dico)