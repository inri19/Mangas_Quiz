from django.urls import path
from .views import *

urlpatterns=[
path('', home, name='home'),
path('addListe/', addListe, name='addListe'),
path('addQuestion/<int:liste_id>', addQuestion, name='addQuestion'),
path('liste/', liste, name='liste'),
path('quiz_page/<int:liste_id>', quizPage, name='QuizPage')
]